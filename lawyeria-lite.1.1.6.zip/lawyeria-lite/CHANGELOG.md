

### 1.1.5 - 20/11/2015

 Changes: 


 * Fixed #20 Firefox wrap text issue
 * Added translations .pot file


### 1.1.4 - 16/07/2015

 Changes: 


 * Update class-tgm-plugin-activation to latest version
 * Update style.css


### 1.1.3 - 14/07/2015

 Changes: 


 * Update class-tgm-plugin-activation to latest version

to fix issues caused by older versions
 * Update style.css


### 1.1.2 - 03/06/2015

 Changes: 


 * Fixed #23 Menu issue
 * Fixed #22 Looks very strange in IE browsers
 * Update style.css


### 1.1.1 - 09/04/2015

 Changes: 


 * Update demo link


### 1.1.0 - 06/04/2015

 Changes: 


 * Fixed #3, link in footer, powered by wordpress
 * Fixed #11, added Leave us a review button in customizer
 * Fixed #6, increase menu limit to allow more items
 * Fixed #5, added demo link in description and update style.css version


### 1.0.10 - 26/03/2015

 Changes: 


 * Removed contact form and form from frontpage


### 1.0.10 - 26/03/2015

 Changes: 


 * Update style.css


### 1.0.9 - 26/03/2015

 Changes: 


 * Replaced header image and screenshot
 * This fixes #13

Provided demo link for 'View Theme Demo'
 * New header and screenshot
 * This fixes #12

Upsaled in customizer + buttons for 'View PRO Version' and
'Documentation'
 * This fixes #14

Correct formats for the images
Placed $input as a parameter
 * Merge pull request #14 from DragosBubu/development

Replaced header image and screenshot


### 1.0.8 - 30/01/2015

 Changes: 


 * Update style.css
 * Update style.css
 * Update style.css
 * removed unused css+images for testimonials

removed unused css+images for testimonials


### 1.0.7 - 03/01/2015

 Changes: 


 * fixed customizer sanitization and remove screen_icon function deprecated
 * fixed rtl and removed header css
 * improved fonts loading


### 1.0.4 - 17/10/2014

 Changes: 


 * Version 1.0.1
 * Fixed 404 syntax error
 * Fixed title for logo
 * Fixed customizer syntax error
 * Update version to 1.0.2
 * Added rel=nofollow to footer link
 * Update version to 1.0.3
 * Fixed dropdown menu for large items
 * Up
